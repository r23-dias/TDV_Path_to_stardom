﻿using var game = new Path_to_stardom_TDV.Game1();
game.Run();
