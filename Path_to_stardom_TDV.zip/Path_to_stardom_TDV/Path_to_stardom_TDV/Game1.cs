﻿using Microsoft.Xna.Framework;
using Microsoft.Xna.Framework.Content;
using Microsoft.Xna.Framework.Graphics;
using Microsoft.Xna.Framework.Input;
using System;
using System.Collections.Generic;

namespace Path_to_stardom_TDV
{
    public class Game1 : Game
    {
        private GraphicsDeviceManager _graphics;
        private SpriteBatch _spriteBatch;
        private Fighter player1;
        private Fighter player2;
        private DynamicBackground background;
        private KeyboardState currentKeyboardState;
        private KeyboardState previousKeyboardState;

        public Game1()
        {
            _graphics = new GraphicsDeviceManager(this);
            Content.RootDirectory = "Content";
            IsMouseVisible = true;

            // Mantém sua resolução de 1280x720 mas em tela cheia
            _graphics.PreferredBackBufferWidth = 1280;
            _graphics.PreferredBackBufferHeight = 720;
            _graphics.IsFullScreen = true;
            _graphics.ApplyChanges();
        }

        protected override void Initialize()
        {
            player1 = new Fighter("Player1", "MKing", new Vector2(100, 200), Color.White);
            player2 = new Fighter("Player2", "FWarrior", new Vector2(720, 212), Color.White);
            background = new DynamicBackground();
            base.Initialize();
        }

        protected override void LoadContent()
        {
            _spriteBatch = new SpriteBatch(GraphicsDevice);
            player1.LoadContent(Content);
            player2.LoadContent(Content);
            background.LoadContent(Content);
        }

        protected override void Update(GameTime gameTime)
        {
            previousKeyboardState = currentKeyboardState;
            currentKeyboardState = Keyboard.GetState();

            if (GamePad.GetState(PlayerIndex.One).Buttons.Back == ButtonState.Pressed || currentKeyboardState.IsKeyDown(Keys.Escape))
                Exit();

            player1.Update(gameTime, currentKeyboardState, previousKeyboardState, player2);
            player2.Update(gameTime, currentKeyboardState, previousKeyboardState, player1);
            background.Update(gameTime);

            base.Update(gameTime);
        }

        protected override void Draw(GameTime gameTime)
        {
            GraphicsDevice.Clear(Color.Black);
            _spriteBatch.Begin();
            background.Draw(_spriteBatch);
            player1.Draw(_spriteBatch, GraphicsDevice);
            player2.Draw(_spriteBatch, GraphicsDevice);
            DrawHealthBars();
            _spriteBatch.End();
            base.Draw(gameTime);
        }

        private void DrawHealthBars()
        {
            // Barra de vida do Player 1
            Rectangle healthBarP1 = new Rectangle(50, 50, 500, 30);
            Rectangle currentHealthP1 = new Rectangle(50, 50, (int)(500 * (player1.Health / 100f)), 30);

            _spriteBatch.Draw(CreateColorTexture(Color.Gray), healthBarP1, Color.White);
            _spriteBatch.Draw(CreateColorTexture(Color.Green), currentHealthP1, Color.White);

            // Barra de vida do Player 2
            Rectangle healthBarP2 = new Rectangle(730, 50, 500, 30);
            Rectangle currentHealthP2 = new Rectangle(730, 50, (int)(500 * (player2.Health / 100f)), 30);

            _spriteBatch.Draw(CreateColorTexture(Color.Gray), healthBarP2, Color.White);
            _spriteBatch.Draw(CreateColorTexture(Color.Green), currentHealthP2, Color.White);
        }

        private Texture2D CreateColorTexture(Color color)
        {
            Texture2D texture = new Texture2D(GraphicsDevice, 1, 1);
            texture.SetData(new[] { color });
            return texture;
        }
    }

    public enum AnimationState
    {
        Idle,
        Walk,
        Attack1,
        Attack2,
        Attack3,
        Jump
    }

    public class Animation
    {
        public Texture2D SpriteSheet { get; private set; }
        public int FrameWidth { get; private set; }
        public int FrameHeight { get; private set; }
        public int NumberOfFrames { get; private set; }
        public float FrameDuration { get; private set; }

        public Animation(Texture2D spriteSheet, int frameWidth, int frameHeight, int numberOfFrames, float frameDuration)
        {
            SpriteSheet = spriteSheet;
            FrameWidth = frameWidth;
            FrameHeight = frameHeight;
            NumberOfFrames = numberOfFrames;
            FrameDuration = frameDuration;
        }
    }

    public class AttackInfo
    {
        public string Name { get; }
        public AnimationState AnimationState { get; }
        public int Damage { get; }
        public List<Rectangle> Hitboxes { get; }  // Lista de hitboxes
        public int ActiveStartFrame { get; }
        public int ActiveEndFrame { get; }

        public AttackInfo(string name, AnimationState animationState, int damage,
                         List<Rectangle> hitboxes, int activeStart, int activeEnd)
        {
            Name = name;
            AnimationState = animationState;
            Damage = damage;
            Hitboxes = hitboxes;
            ActiveStartFrame = activeStart;
            ActiveEndFrame = activeEnd;
        }
    }

    public class Fighter
    {
        public string Name { get; private set; }
        public string CharacterType { get; private set; }
        public Vector2 Position { get; private set; }
        public float Health { get; private set; } = 100f;
        public bool IsAttacking { get; private set; }
        public bool IsJumping { get; private set; }
        public bool HasHit { get; private set; }
        public int AttackDamage { get; private set; }
        public Rectangle Hitbox { get; private set; }
        public List<Rectangle> AttackHitboxes { get; private set; } = new List<Rectangle>();
        public bool ShowHitboxes = true;

        private Dictionary<string, AttackInfo> _attacks = new Dictionary<string, AttackInfo>();
        private AttackInfo _currentAttack;
        private Dictionary<AnimationState, Animation> _animations;
        private Animation _currentAnimationData;
        private float _animationFrameTimer;
        private int _currentFrame;
        private Texture2D _hitboxTexture;
        private Color _drawColor;
        private Vector2 _velocity;
        private float _jumpForce = -15f;
        private float _gravity = 0.5f;
        private float _moveSpeed = 5f;
        private float _groundY = 200f;
        private AnimationState _currentFighterState;
        private bool _isFacingRight;

        public Fighter(string name, string characterType, Vector2 position, Color drawColor)
        {
            Name = name;
            CharacterType = characterType;
            Position = position;
            _drawColor = drawColor;
            _animations = new Dictionary<AnimationState, Animation>();
            _currentFighterState = AnimationState.Idle;
            _isFacingRight = (position.X < 640);
            InitializeAttacks();
            _groundY = position.Y;
        }

        public void LoadContent(ContentManager content)
        {
            if (CharacterType == "MKing")
            {
                _animations.Add(AnimationState.Idle, new Animation(content.Load<Texture2D>("MKing/MKingIdle"), 160, 111, 8, 0.12f));
                _animations.Add(AnimationState.Walk, new Animation(content.Load<Texture2D>("MKing/MKingWalk"), 160, 111, 8, 0.08f));
                _animations.Add(AnimationState.Attack1, new Animation(content.Load<Texture2D>("MKing/MKingAttack1"), 160, 111, 4, 0.1f));
                _animations.Add(AnimationState.Attack2, new Animation(content.Load<Texture2D>("MKing/MKingAttack2"), 160, 111, 4, 0.12f));
                _animations.Add(AnimationState.Attack3, new Animation(content.Load<Texture2D>("MKing/MKingAttack3"), 160, 111, 4, 0.14f));
            }
            else if (CharacterType == "FWarrior")
            {
                _animations.Add(AnimationState.Idle, new Animation(content.Load<Texture2D>("FWarrior/FWarriorIdle"), 162, 162, 10, 0.12f));
                _animations.Add(AnimationState.Walk, new Animation(content.Load<Texture2D>("FWarrior/FWarriorWalk"), 162, 162, 8, 0.08f));
                _animations.Add(AnimationState.Attack1, new Animation(content.Load<Texture2D>("FWarrior/FWarriorAttack1"), 162, 162, 7, 0.09f));
                _animations.Add(AnimationState.Attack2, new Animation(content.Load<Texture2D>("FWarrior/FWarriorAttack2"), 162, 162, 7, 0.11f));
                _animations.Add(AnimationState.Attack3, new Animation(content.Load<Texture2D>("FWarrior/FWarriorAttack3"), 162, 162, 8, 0.13f));
            }

            _currentAnimationData = _animations[_currentFighterState];
            _hitboxTexture = new Texture2D(_currentAnimationData.SpriteSheet.GraphicsDevice, 1, 1);
            _hitboxTexture.SetData(new[] { Color.White });
        }

        public void Update(GameTime gameTime, KeyboardState currentKeyboardState, KeyboardState previousKeyboardState, Fighter opponent)
        {
            float deltaTime = (float)gameTime.ElapsedGameTime.TotalSeconds;

            if (IsJumping)
            {
                _velocity.Y += _gravity;
                Position += new Vector2(0, _velocity.Y);
                if (Position.Y >= _groundY)
                {
                    Position = new Vector2(Position.X, _groundY); // Força a posição exata
                    IsJumping = false;
                    _velocity.Y = 0;
                    if (_currentFighterState == AnimationState.Jump)
                        SetFighterState(AnimationState.Idle);
                }
            }

            bool movingHorizontally = false;
            if (Name == "Player1")
            {
                if (currentKeyboardState.IsKeyDown(Keys.A))
                {
                    Position = new Vector2(Position.X - _moveSpeed, Position.Y);
                    movingHorizontally = true;
                    _isFacingRight = false;
                }
                if (currentKeyboardState.IsKeyDown(Keys.D))
                {
                    Position = new Vector2(Position.X + _moveSpeed, Position.Y);
                    movingHorizontally = true;
                    _isFacingRight = true;
                }
                if (currentKeyboardState.IsKeyDown(Keys.W) && !previousKeyboardState.IsKeyDown(Keys.W))
                {
                    Jump();
                }
                if (currentKeyboardState.IsKeyDown(Keys.F) && !previousKeyboardState.IsKeyDown(Keys.F))
                {
                    MKAttack1();
                }
                if (currentKeyboardState.IsKeyDown(Keys.G) && !previousKeyboardState.IsKeyDown(Keys.G))
                {
                    MKAttack2();
                }
                if (currentKeyboardState.IsKeyDown(Keys.H) && !previousKeyboardState.IsKeyDown(Keys.H))
                {
                    MKAttack3();
                }
            }
            else if (Name == "Player2")
            {
                if (currentKeyboardState.IsKeyDown(Keys.Left))
                {
                    Position = new Vector2(Position.X - _moveSpeed, Position.Y);
                    movingHorizontally = true;
                    _isFacingRight = false;
                }
                if (currentKeyboardState.IsKeyDown(Keys.Right))
                {
                    Position = new Vector2(Position.X + _moveSpeed, Position.Y);
                    movingHorizontally = true;
                    _isFacingRight = true;
                }
                if (currentKeyboardState.IsKeyDown(Keys.Up) && !previousKeyboardState.IsKeyDown(Keys.Up))
                {
                    Jump();
                }
                if (currentKeyboardState.IsKeyDown(Keys.NumPad1) && !previousKeyboardState.IsKeyDown(Keys.NumPad1))
                {
                    FWAttack1();
                }
                if (currentKeyboardState.IsKeyDown(Keys.NumPad2) && !previousKeyboardState.IsKeyDown(Keys.NumPad2))
                {
                    FWAttack2();
                }
                if (currentKeyboardState.IsKeyDown(Keys.NumPad3) && !previousKeyboardState.IsKeyDown(Keys.NumPad3))
                {
                    FWAttack3();
                }
            }

            if (!IsAttacking && !IsJumping)
            {
                SetFighterState(movingHorizontally ? AnimationState.Walk : AnimationState.Idle);
            }

            _animationFrameTimer += deltaTime;
            if (_animationFrameTimer >= _currentAnimationData.FrameDuration)
            {
                _animationFrameTimer -= _currentAnimationData.FrameDuration;
                _currentFrame = (_currentFrame + 1) % _currentAnimationData.NumberOfFrames;

                if (_currentFighterState.ToString().StartsWith("Attack") && _currentFrame == 0 && IsAttacking)
                {
                    IsAttacking = false;
                    HasHit = false;
                    SetFighterState(AnimationState.Idle);
                }
            }

            UpdateHitboxes();
        }

        private void InitializeAttacks()
        {
            if (CharacterType == "MKing")
            {
                    // MKAttack1 - Ataque Rápido
                    _attacks.Add("MKAttack1", new AttackInfo(
                "MKAttack1", AnimationState.Attack1, 10,
                new List<Rectangle> {
                    new Rectangle(280, 220, 170, 30),  
                    new Rectangle(220, 190, 160, 30),
                    new Rectangle(220, 250, 160, 30)
                },
                1, 3));

                    // MKAttack2 - Ataque Médio
                    _attacks.Add("MKAttack2", new AttackInfo(
                "MKAttack2", AnimationState.Attack2, 10,
                new List<Rectangle> {
                        new Rectangle(220, 220, 60, 30),  
                        new Rectangle(90, 20, 70, 40)  
                },
                1, 3));

                    // MKAttack3 - Ataque Forte
                    _attacks.Add("MKAttack3", new AttackInfo(
                "MKAttack3", AnimationState.Attack3, 10,
                new List<Rectangle> {
                            new Rectangle(220, 220, 60, 30), 
                            new Rectangle(90, 20, 70, 40) 
                },
                1, 3));
            }
            else if (CharacterType == "FWarrior")
            {
                    // FWAttack1 - Ataque Rápido
                    _attacks.Add("FWAttack1", new AttackInfo(
                "FWAttack1", AnimationState.Attack1, 10,
                new List<Rectangle> {
                        new Rectangle(220, 220, 60, 30),  
                        new Rectangle(90, 20, 70, 40)   
                },
                1, 3));

                    // FWAttack2 - Ataque Médio
                    _attacks.Add("FWAttack2", new AttackInfo(
                "FWAttack2", AnimationState.Attack2, 10,
                new List<Rectangle> {
                            new Rectangle(220, 220, 60, 30),
                            new Rectangle(90, 20, 70, 40)  
                },
                1, 3));

                    // FWAttack3 - Ataque Forte
                    _attacks.Add("FWAttack3", new AttackInfo(
                "FWAttack3", AnimationState.Attack3, 10,
                new List<Rectangle> {
                                new Rectangle(220, 220, 60, 30), 
                                new Rectangle(90, 20, 70, 40)   
                },
                1, 3));
            }
        }


        private void UpdateHitboxes()
        {
            const float scale = 3f;
            int spriteWidth = _currentAnimationData.FrameWidth;
            int spriteHeight = _currentAnimationData.FrameHeight;

            // Hitbox principal do personagem
            int hitboxWidth = spriteWidth;
            int hitboxHeight = spriteHeight;
            int offsetX = 0;
            int offsetY = 0;

            if (CharacterType == "MKing")
            {
                hitboxWidth = (int)(spriteWidth * 0.15f);
                hitboxHeight = (int)(spriteHeight * 0.5f);
                offsetX = (int)(spriteWidth * 1.35f);
                offsetY = (int)(spriteHeight * 1.4f);
            }
            else if (CharacterType == "FWarrior")
            {
                hitboxWidth = (int)(spriteWidth * 0.14f);
                hitboxHeight = (int)(spriteHeight * 0.3f);
                offsetX = (int)(spriteWidth * 1.3f);
                offsetY = (int)(spriteHeight * 1f);
            }

            Hitbox = new Rectangle(
                (int)Position.X + offsetX,
                (int)Position.Y + offsetY,
                (int)(hitboxWidth * scale),
                (int)(hitboxHeight * scale)
            );

            // Limpa as hitboxes de ataque
            AttackHitboxes.Clear();

            // Se estiver atacando e no frame ativo, calcula as hitboxes de ataque
            if (IsAttacking && _currentAttack != null &&
                _currentFrame >= _currentAttack.ActiveStartFrame &&
                _currentFrame <= _currentAttack.ActiveEndFrame)
            {
                foreach (var hitbox in _currentAttack.Hitboxes)
                {
                    Rectangle actualHitbox = new Rectangle(
                        (int)Position.X + (_isFacingRight ? hitbox.X : -hitbox.X - hitbox.Width),
                        (int)Position.Y + hitbox.Y,
                        hitbox.Width,
                        hitbox.Height
                    );
                    AttackHitboxes.Add(actualHitbox);
                }
            }
        }


        public void Draw(SpriteBatch spriteBatch, GraphicsDevice graphicsDevice)
        {
            SpriteEffects effect = _isFacingRight ? SpriteEffects.None : SpriteEffects.FlipHorizontally;
            Rectangle sourceRect = new Rectangle(
                _currentFrame * _currentAnimationData.FrameWidth,
                0,
                _currentAnimationData.FrameWidth,
                _currentAnimationData.FrameHeight
            );

            spriteBatch.Draw(
                _currentAnimationData.SpriteSheet,
                Position,
                sourceRect,
                _drawColor,
                0f,
                Vector2.Zero,
                3f,
                effect,
                0f
            );

            if (ShowHitboxes)
            {
                if (_hitboxTexture == null)
                {
                    _hitboxTexture = new Texture2D(graphicsDevice, 1, 1);
                    _hitboxTexture.SetData(new[] { Color.White });
                }

                // Desenha a hitbox principal (vermelha)
                spriteBatch.Draw(_hitboxTexture, Hitbox, Color.Red * 0.5f);

                // Desenha todas as hitboxes de ataque (azuis)
                foreach (var hitbox in AttackHitboxes)
                {
                    spriteBatch.Draw(_hitboxTexture, hitbox, Color.Blue * 0.5f);
                }
            }
        }

        private void SetFighterState(AnimationState newState)
        {
            if (_currentFighterState == newState) return;

            _currentFighterState = newState;
            _currentAnimationData = _animations[newState];
            _currentFrame = 0;
            _animationFrameTimer = 0;

            if (newState.ToString().StartsWith("Attack"))
            {
                IsAttacking = true;
                HasHit = false;
            }
        }

        public void Jump()
        {
            if (!IsJumping)
            {
                IsJumping = true;
                _velocity.Y = _jumpForce;
                if (_animations.ContainsKey(AnimationState.Jump))
                    SetFighterState(AnimationState.Jump);
            }
        }

        public void MKAttack1()
        {
            if (!IsAttacking && _attacks.TryGetValue("MKAttack1", out var attack))
            {
                _currentAttack = attack;
                AttackDamage = attack.Damage;
                SetFighterState(attack.AnimationState);
            }
        }

        public void MKAttack2()
        {
            if (!IsAttacking && _attacks.TryGetValue("MKAttack2", out var attack))
            {
                _currentAttack = attack;
                AttackDamage = attack.Damage;
                SetFighterState(attack.AnimationState);
            }
        }

        public void MKAttack3()
        {
            if (!IsAttacking && _attacks.TryGetValue("MKAttack3", out var attack))
            {
                _currentAttack = attack;
                AttackDamage = attack.Damage;
                SetFighterState(attack.AnimationState);
            }
        }

        public void FWAttack1()
        {
            if (!IsAttacking && _attacks.TryGetValue("FWAttack1", out var attack))
            {
                _currentAttack = attack;
                AttackDamage = attack.Damage;
                SetFighterState(attack.AnimationState);
            }
        }

        public void FWAttack2()
        {
            if (!IsAttacking && _attacks.TryGetValue("FWAttack2", out var attack))
            {
                _currentAttack = attack;
                AttackDamage = attack.Damage;
                SetFighterState(attack.AnimationState);
            }
        }

        public void FWAttack3()
        {
            if (!IsAttacking && _attacks.TryGetValue("FWAttack3", out var attack))
            {
                _currentAttack = attack;
                AttackDamage = attack.Damage;
                SetFighterState(attack.AnimationState);
            }
        }
    }

    public class DynamicBackground
    {
        private Texture2D _backgroundTexture1;
        private Texture2D _backgroundTexture2;
        private Vector2 _backgroundPosition1;
        private Vector2 _backgroundPosition2;
        private float _scrollSpeed1 = 0.5f;
        private float _scrollSpeed2 = 0.2f;

        public void LoadContent(ContentManager content)
        {
            try
            {
                _backgroundTexture1 = content.Load<Texture2D>("background_layer1");
                _backgroundTexture2 = content.Load<Texture2D>("background_layer2");
            }
            catch { /* Ignorar se as texturas não existirem */ }
        }

        public void Update(GameTime gameTime)
        {
            if (_backgroundTexture1 == null) return;

            float deltaTime = (float)gameTime.ElapsedGameTime.TotalSeconds;
            _backgroundPosition1.X -= _scrollSpeed1;

            if (_backgroundTexture2 != null)
                _backgroundPosition2.X -= _scrollSpeed2;

            if (_backgroundPosition1.X <= -_backgroundTexture1.Width)
                _backgroundPosition1.X = 0;

            if (_backgroundTexture2 != null && _backgroundPosition2.X <= -_backgroundTexture2.Width)
                _backgroundPosition2.X = 0;
        }

        public void Draw(SpriteBatch spriteBatch)
        {
            if (_backgroundTexture1 == null) return;

            if (_backgroundTexture2 != null)
            {
                spriteBatch.Draw(_backgroundTexture2, _backgroundPosition2, Color.White);
                spriteBatch.Draw(_backgroundTexture2, _backgroundPosition2 + new Vector2(_backgroundTexture2.Width, 0), Color.White);
            }

            spriteBatch.Draw(_backgroundTexture1, _backgroundPosition1, Color.White);
            spriteBatch.Draw(_backgroundTexture1, _backgroundPosition1 + new Vector2(_backgroundTexture1.Width, 0), Color.White);
        }
    }
}
